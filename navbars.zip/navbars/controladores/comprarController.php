<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cantidad = intval($_POST['cantidad']);
    $precioEmpanada = 2500;

    if ($cantidad <= 0) {
        // Redirigir con un mensaje de error
        header('Location: ../public/comprar.php?error=1');
    } else {
        $total = $cantidad * $precioEmpanada;
        // Redirigir con el total a pagar
        header('Location: ../public/comprar.php?total=' . $total);
    }
} else {
    echo "Método no permitido.";
}
