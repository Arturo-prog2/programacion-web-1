<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cantidad = intval($_POST['cantidad']);
    $precioEmpanada = 2500;

    if ($cantidad <= 0) {
        $error = urlencode("Ojo, valor inválido. La cantidad debe ser mayor a cero.");
        header("Location: ../public/vender.php?error=$error");
        exit;
    } else {
        $total = $cantidad * $precioEmpanada;
        header("Location: ../public/vender.php?cantidad=$cantidad&total=$total");
        exit;
    }
} else {
    echo "Método no permitido.";
}
