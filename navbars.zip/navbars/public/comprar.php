<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comprar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Comprar Empanadas</h2>
        <form action="../controladores/comprarController.php" method="POST">
            <div class="mb-3">
                <label for="cantidad" class="form-label">Cantidad de Empanadas</label>
                <input type="number" name="cantidad" id="cantidad" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Calcular Total</button>
        </form>

        <!-- Mensaje de resultado (mostrado después del envío del formulario) -->
        <?php
        if (isset($_GET['total'])) {
            $total = intval($_GET['total']);
            echo "<div class='alert alert-success mt-3'>Total a pagar: $total pesos.</div>";
        } elseif (isset($_GET['error'])) {
            echo "<div class='alert alert-danger mt-3'>Ojo, valor inválido. La cantidad debe ser mayor a cero.</div>";
        }
        ?>
    </div>
</body>
</html>
