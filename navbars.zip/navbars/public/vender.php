<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vender Empanadas</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Vender Empanadas</h2>
        <form action="../controladores/venderController.php" method="POST">
            <div class="mb-3">
                <label for="cantidad" class="form-label">Cantidad de Empanadas</label>
                <input type="number" name="cantidad" id="cantidad" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Calcular Total</button>
        </form>

        <?php if (isset($_GET['total']) && isset($_GET['cantidad']) && $_GET['cantidad'] > 0): ?>
            <div class="mt-4 alert alert-success">
                <h4>Detalle de la compra</h4>
                <p>Producto: <strong>Empanada</strong></p>
                <p>Cantidad: <strong><?php echo htmlspecialchars($_GET['cantidad']); ?></strong></p>
                <p>Total a pagar: <strong><?php echo htmlspecialchars($_GET['total']); ?> pesos</strong></p>
            </div>
        <?php elseif (isset($_GET['error'])): ?>
            <div class="mt-4 alert alert-danger">
                <strong><?php echo htmlspecialchars($_GET['error']); ?></strong>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
